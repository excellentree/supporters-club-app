# SUPPORTERS CULB Web App
Next.js + Supabase prototype. Customer catalog/cart/LINE order and a basic admin registration page.
Before production, add Supabase Auth and proper RLS policies for admin writes.
