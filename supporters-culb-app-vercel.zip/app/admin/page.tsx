'use client'
import {useState} from 'react'
import {supabase} from '../../lib/supabase'

export default function Admin(){
 const [form,setForm]=useState({name:'',version:'',model:'',category:'SOCCERWE',item_type:'代表',region:'ヨーロッパ',country_or_club:'',price:''})
 const [msg,setMsg]=useState('')
 const set=(k:string,v:string)=>setForm({...form,[k]:v})
 const save=async()=>{
   const {error}=await supabase.from('products').insert({...form,price:Number(form.price)})
   setMsg(error?`登録エラー: ${error.message}`:'商品を登録しました！')
   if(!error)setForm({...form,name:'',version:'',model:'',country_or_club:'',price:''})
 }
 return <main className="admin"><h1>商品登録</h1>
  {Object.entries(form).map(([k,v])=><label key={k}>{k}<input value={v} onChange={e=>set(k,e.target.value)} /></label>)}
  <button className="add" onClick={save}>登録する</button><p>{msg}</p>
 </main>
}
