import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'SUPPORTERS CULB',
  description: 'Football goods catalog and LINE ordering app'
}

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="ja"><body>{children}</body></html>
}
