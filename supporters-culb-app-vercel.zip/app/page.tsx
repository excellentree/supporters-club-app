'use client'
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

type Product = {
  id:number; name:string; version:string|null; model:string|null; category:string|null;
  item_type:string|null; region:string|null; country_or_club:string|null; price:number;
  image_url?:string|null
}

export default function Home() {
  const [products,setProducts]=useState<Product[]>([])
  const [cart,setCart]=useState<Product[]>([])
  const [loading,setLoading]=useState(true)

  useEffect(()=>{ (async()=>{
    const {data,error}=await supabase.from('products').select('*').order('id',{ascending:false})
    if(!error && data) setProducts(data as Product[])
    setLoading(false)
  })()},[])

  const add=(p:Product)=>setCart(c=>[...c,p])
  const remove=(id:number)=>setCart(c=>{const i=c.findIndex(x=>x.id===id); if(i<0)return c; return [...c.slice(0,i),...c.slice(i+1)]})
  const orderText = `【SUPPORTERS CULB 注文】\n\n${cart.map((p,i)=>`${i+1}. ${p.name} / ${p.version||''} / ${p.model||''} / ¥${p.price.toLocaleString()}`).join('\n')}\n\n合計 ¥${cart.reduce((s,p)=>s+p.price,0).toLocaleString()}`
  const lineUrl = `https://line.me/R/oaMessage/%40163shzbn/?${encodeURIComponent(orderText)}`

  return <main>
    <header><div className="logo">SUPPORTERS CULB</div><div className="sub">FOOTBALL GOODS</div></header>
    <section className="hero"><h1>SOCCERWE</h1><p>サッカーグッズを選んで注文</p></section>
    <div className="content">
      <div className="filters">
        <button>代表</button><button>クラブ</button>
      </div>
      {loading ? <p>読み込み中…</p> :
       products.length===0 ? <p>商品がまだ登録されていません。</p> :
       <div className="grid">{products.map(p=><article className="card" key={p.id}>
         <div className="photo">{p.image_url ? <img src={p.image_url} alt={p.name}/> : <span>NO IMAGE</span>}</div>
         <div className="details">
           <div><b>NAME</b><span>{p.name}</span></div>
           <div><b>VERSION</b><span>{p.version||'-'}</span></div>
           <div><b>MODEL</b><span>{p.model||'-'}</span></div>
           <div><b>PRICE</b><strong>¥{p.price.toLocaleString()}</strong></div>
         </div>
         <button className="add" onClick={()=>add(p)}>カートに入れる</button>
       </article>)}</div>}
    </div>
    <aside className="cart">
      <div className="cartHead"><b>カート</b><span>{cart.length}点</span></div>
      {cart.length===0 ? <p>商品を追加してください。</p> :
       <>{cart.map((p,i)=><div className="cartItem" key={`${p.id}-${i}`}><span>{p.name} ¥{p.price.toLocaleString()}</span><button onClick={()=>remove(p.id)}>削除</button></div>)}
       <div className="total">合計 ¥{cart.reduce((s,p)=>s+p.price,0).toLocaleString()}</div>
       <a className="line" href={lineUrl}>LINEで注文する</a></>}
    </aside>
  </main>
}
